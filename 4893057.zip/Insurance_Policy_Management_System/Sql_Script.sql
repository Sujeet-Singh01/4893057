-- CREATING Insurance Policies Table
CREATE TABLE InsurancePolicies(
    POLICY_ID NUMBER PRIMARY KEY,
    CUSTOMER_ID NUMBER NOT NULL,
    POLICY_TYPE VARCHAR2(50) NOT NULL,
    START_DATE DATE NOT NULL,
    END_DATE DATE NOT NULL,
    STATUS VARCHAR2(50) NOT NULL);
   
    
-- CREATING Policy Processings Table
CREATE TABLE PolicyProcessings(
    PROCESSING_ID NUMBER PRIMARY KEY,
    POLICY_ID NUMBER NOT NULL,
    PROCESSING_DATE DATE NOT NULL,
    DECISION VARCHAR2(50) NOT NULL,
    REMARKS VARCHAR2(255),
    CONSTRAINT fk_PolicyId foreign KEY(POLICY_ID) REFERENCES InsurancePolicies(POLICY_ID) ON DELETE CASCADE
    );
    


-- CREATING Policy Reports Table
CREATE TABLE PolicyReports(
    REPORT_ID NUMBER PRIMARY KEY, 
    REPORT_DATE DATE NOT NULL,
    TOTAL_POLICIES NUMBER,
    ACTIVE_POLICIES NUMBER,
    EXPIRED_POLICIES NUMBER,
    PENDING_REQUESTS NUMBER);
    
---------------------------------------------------------------------------------------------------------------------------------------------------------
-- Inserting sample data into InsurancePolicies table

INSERT INTO InsurancePolicies
(POLICY_ID, CUSTOMER_ID, POLICY_TYPE, START_DATE, END_DATE, STATUS)
VALUES (1, 101, 'Life Insurance', TO_DATE('2024-08-30', 'YYYY-MM-DD'), TO_DATE('2024-10-30', 'YYYY-MM-DD'), 'Active');

INSERT INTO InsurancePolicies VALUES (2, 102, 'Property Insurance', TO_DATE('2023-05-15', 'YYYY-MM-DD'), TO_DATE('2024-05-15', 'YYYY-MM-DD'), 'Expired');

INSERT INTO InsurancePolicies VALUES (3, 103, 'Bike Insurance', TO_DATE('2024-05-10', 'YYYY-MM-DD'), TO_DATE('2024-11-10', 'YYYY-MM-DD'), 'Active');

INSERT INTO InsurancePolicies VALUES (4, 104, 'Travel Insurance', TO_DATE('2024-10-01', 'YYYY-MM-DD'), TO_DATE('2025-05-01', 'YYYY-MM-DD'), 'Upcomming');

-- To insert multiple rows at a time
INSERT ALL
INTO InsurancePolicies VALUES (5, 105, 'Car Insurance', TO_DATE('2023-10-10', 'YYYY-MM-DD'), TO_DATE('2026-10-10', 'YYYY-MM-DD'), 'Active')
INTO InsurancePolicies VALUES (6, 106, 'Pet Insurance', TO_DATE('2024-12-02', 'YYYY-MM-DD'), TO_DATE('2025-06-02', 'YYYY-MM-DD'), 'Upcomming')
SELECT * FROM DUAL;

------------------------------------------------------------------------------------------------------------------------------------------------------------------    
-- Inserting sample data into PolicyProcessing table
INSERT ALL
INTO PolicyProcessings
(PROCESSING_ID, POLICY_ID, PROCESSING_DATE, DECISION, REMARKS) 
                       VALUES (1, 1, TO_DATE('2024-08-30', 'YYYY-MM-DD'), 'Approved', 'Approved Successfully')
INTO PolicyProcessings VALUES (2, 2, TO_DATE('2024-05-16', 'YYYY-MM-DD'), 'Expired', 'Policy Expired')
INTO PolicyProcessings VALUES (3, 3, TO_DATE('2024-05-10', 'YYYY-MM-DD'), 'Approved', 'Approved Successfully')
INTO PolicyProcessings VALUES (4, 4, TO_DATE('2024-05-16', 'YYYY-MM-DD'), 'Pending', 'Payment is Pending')
INTO PolicyProcessings VALUES (5, 5, TO_DATE('2024-05-16', 'YYYY-MM-DD'), 'Approved', 'Approved Successfully')
SELECT * FROM DUAL;