-- Documentation and Testing 

-- Step 1: Execute the SQL script.
-- Step 2: Execute each procedures separately.
-- Step 3: Test the code using given below examples how to execute the procedures and what all parameters we have to pass while executing the procedures.

1. Setting up:
    (i) Execute the SQL scripts to create the InsurancePolicies, PolicyProcessings, and PolicyReports tables.
    (ii) Populate the tables with sample data using the provided INSERT statements.
    
    
2. Running Procedures:
    (i) To manage policies (inserting, updating and deleting), use the 'manage_policies' procedure 
	by passing (action_type, policy_id, customer_id, policy_type, start_date, end_date, status).
        For eg.
        
       	 -- Check the InsurancePolicies table
	SELECT * FROM InsurancePolicies;

	-- Now using the manage policy procedure to insert the record into InsurancePolicies table
	EXEC manage_policy('INSERT', 7 , 107, 'Pet Insurance', TO_DATE('2024-01-20', 'YYYY-MM-DD'), TO_DATE('2025-01-20', 'YYYY-MM-DD'), 'Active');
	-- Checking the newly inserted record
	SELECT * FROM InsurancePolicies;

	-- Now updating the record with policy_id = 5
	EXEC manage_policy('UPDATE', 5, 105, 'Device Insurance', TO_DATE('2020-02-01', 'YYYY-MM-DD'), TO_DATE('2024-02-01', 'YYYY-MM-DD'), 'Expired');
	-- Verify the record in the table
	SELECT * FROM InsurancePolicies;

	-- Now deleting the record with policy_id = 5
	EXEC manage_policy('DELETE', 5, 105, 'Device Insurance', TO_DATE('2020-02-01', 'YYYY-MM-DD'), TO_DATE('2024-02-01', 'YYYY-MM-DD'), 'Expired');
	-- Verify the table
	SELECT * FROM InsurancePolicies;


    (ii) To process a policy request, use the 'process_policy_request' procedure
	by passing (processing_id, policy_id, processing_date, decision, remark).
        For eg.
        
       	-- Now processing the policy request
	EXEC process_policy_request(6, 6, TO_DATE('2024-12-02', 'YYYY-MM-DD'), 'Approved', 'Approved Successfully');
	-- Verifying the PolicyProcessings table
	 SELECT * FROM PolicyProcessings;
             
             This above statement add the data in PolicyProcessings table and update the respective rows in the parent table(InsurancePolicy).

    (iii) To generate a policy report, use the 'generate_policy_report' procedure
	by passing (today's_date).
        For eg.
        
        EXEC generate_policy_report(SYSDATE);


