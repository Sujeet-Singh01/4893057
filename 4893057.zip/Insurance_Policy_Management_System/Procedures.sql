--Procedure for Insurance Policy Management

CREATE OR REPLACE PROCEDURE manage_policy (
    -- Receving the values into variables as an argument while calling the procedure 
    p_action VARCHAR2,
    p_policy_id NUMBER,
    p_customer_id NUMBER,
    p_policy_type VARCHAR2,
    p_start_date DATE,
    p_end_date DATE,
    p_status VARCHAR2) IS
    BEGIN
        -- Inserting the row into InsurancePolicies according to the users action 
        IF p_action = 'INSERT' THEN
            INSERT INTO InsurancePolicies(POLICY_ID, CUSTOMER_ID, POLICY_TYPE, START_DATE, END_DATE, STATUS)
            VALUES (p_policy_id, p_customer_id, p_policy_type, p_start_date, p_end_date, p_status);
        
        -- Updating the row of InsurancePolicies
        ELSIF p_action = 'UPDATE' THEN
            UPDATE InsurancePolicies
            SET CUSTOMER_ID = p_customer_id, POLICY_TYPE = p_policy_type, START_DATE = p_start_date, END_DATE = p_end_date, STATUS = p_status
            WHERE POLICY_ID = p_policy_id;
        
        -- Deleting the row from InsurancePolicies
        ELSIF p_action = 'DELETE' THEN
            DELETE FROM InsurancePolicies WHERE POLICY_ID = p_policy_id;
        
        END IF;
        
    END;
    
--------------------------------------------------------------------------------------------------------------------------------------------------

-- Procedure for Policy Processing

CREATE OR REPLACE PROCEDURE process_policy_request (
    -- Receving the values into variables as an argument while calling the procedure
    p_processing_id NUMBER,
    p_policy_id NUMBER,
    p_processing_date DATE,
    p_decision VARCHAR2,
    p_remarks VARCHAR2) IS
    BEGIN
    -- Inserting into PolicyProcessings table if there is respective policy_id in InsurancePolicies table(parent table)
    INSERT INTO PolicyProcessings(PROCESSING_ID, POLICY_ID, PROCESSING_DATE, DECISION, REMARKS)
    VALUES (p_processing_id, p_policy_id, p_processing_date, p_decision, p_remarks);
    
    -- Updating the status to Active in InsurancePolicies when the decision is Approved
    IF p_decision = 'Approved' THEN
        UPDATE InsurancePolicies
        SET STATUS = 'Active'
        WHERE POLICY_ID = p_policy_id;
        
    -- Updating the status to Expired in InsurancePolicies when the decision is Expired
    ELSIF p_decision = 'Expired' THEN
        UPDATE InsurancePolicies
        SET STATUS = 'Expired'
        WHERE POLICY_ID = p_policy_id;
    
    -- Updating the status to Upcomming in InsurancePolicies when the decision is Pending
    ELSIF p_decision = 'Pending' THEN
        UPDATE InsurancePolicies
        SET STATUS = 'Upcomming'
        WHERE POLICY_ID = p_policy_id;
    END IF;
    /* Handeling the exception when user tries to add policy to the PolicyProcessings(child table)
    when there is no respective policy mapping in InsurancePolicies(parent table)*/
      EXCEPTION
        WHEN others THEN
            dbms_output.put_line('Enter a policy_id whose respective policy_id is also present in parent table');
    
END;

-------------------------------------------------------------------------------------------------------------------------------------------------------
--Procedure for Generating Policy Reports

CREATE OR REPLACE PROCEDURE generate_policy_report (
    -- Receving the date into variable p_report_date as an argument while calling the procedure generate_policy_report
    p_report_date DATE) IS
    p_report_id NUMBER;
    v_total_policies NUMBER;
    v_active_policies NUMBER;
    v_expired_policies NUMBER;
    v_pending_requests NUMBER;
    
BEGIN
    -- Counting the total number of policies
    SELECT COUNT(*) INTO v_total_policies FROM InsurancePolicies;

    -- Counting the total number of active policies
    SELECT COUNT(*) INTO v_active_policies 
    FROM InsurancePolicies 
    WHERE STATUS = 'Active';

    -- Counting the total number of expired policies
    SELECT COUNT(*) INTO v_expired_policies 
    FROM InsurancePolicies 
    WHERE STATUS = 'Expired';

    -- Counting the total number of pending policies
    SELECT COUNT(*) INTO v_pending_requests 
    FROM PolicyProcessings 
    WHERE DECISION = 'Pending';
    
    -- Creating the next report_id number
    SELECT COUNT(*) INTO p_report_id FROM PolicyReports;
    p_report_id := p_report_id + 1;
    
    -- Inserting the values into PolicyReports table
    INSERT INTO PolicyReports (REPORT_ID, REPORT_DATE, TOTAL_POLICIES, ACTIVE_POLICIES, EXPIRED_POLICIES, PENDING_REQUESTS)
    VALUES (p_report_id, p_report_date, v_total_policies, v_active_policies, v_expired_policies, v_pending_requests);
    
    DECLARE 
        myPolicyReport PolicyReports%rowtype;
        BEGIN
            SELECT * INTO myPolicyReport FROM PolicyReports WHERE REPORT_ID = p_report_id;
            
            DBMS_OUTPUT.PUT_LINE('Report_id: ' || myPolicyReport.REPORT_ID);
            DBMS_OUTPUT.PUT_LINE('Report_date: ' || myPolicyReport.REPORT_DATE);
            DBMS_OUTPUT.PUT_LINE('Total Policies: ' || myPolicyReport.TOTAL_POLICIES);
            DBMS_OUTPUT.PUT_LINE('Active Policies: ' || myPolicyReport.ACTIVE_POLICIES);
            DBMS_OUTPUT.PUT_LINE('Expired policies: ' || myPolicyReport.EXPIRED_POLICIES);
            DBMS_OUTPUT.PUT_LINE('Pending Requests: ' || myPolicyReport.PENDING_REQUESTS);
            
        END;
            
END;
